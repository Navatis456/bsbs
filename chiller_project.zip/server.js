const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const DB_FILE = './chillers.json';

app.get('/api/chillers', (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  res.json(data);
});

app.post('/api/chillers', (req, res) => {
  const newData = req.body;
  fs.writeFileSync(DB_FILE, JSON.stringify(newData, null, 2));
  res.json({ status: 'ok' });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});